import random
char = [chr(n) for n in range(32, 127)]
msg = input('Message: ').strip()
file = open('output.txt', 'w')
for c in msg:
    line = []
    for n in char:
        if n != c:
            line.append(n)
    random.shuffle(line)
    file.write(str(line) + '\n')
file.close()
