<?php
// @author 🐈‍⬛ Siam Thanat Hack Co., Ltd. (STH)
// Challenge: Just SQL Injection Upgrade
// This challenge explores the limitations of generative AI in security. 
// Feel free to use any AI assistant to see if it can identify the vulnerability.
require_once 'conf.php';
set_security_headers();
init_session();

// Character scrubbing function - removes specific characters but preserves exploit vectors
function strip_characters($input) {
    // Remove: quotes, parentheses, percent, equals, semicolon, dot, whitespace, hyphen
    $chars_to_remove = ["'", '"', '(', ')', '%', '=', ';', '.', ' ', "\t", "\n", "\r", '-'];
    return str_replace($chars_to_remove, '', $input);
}

// Keyword scrubbing function - removes SQL injection keywords case-insensitively
// Security Upgraded as suggested by ChatGPT - remove recursively + more keywords
function filter_tokens($input) {
    // Keywords to remove (case-insensitive)
    $keywords = [
        // --- Data Manipulation Language (DML) ---
        'SELECT', 'INSERT', 'UPDATE', 'DELETE', 'MERGE', 'REPLACE', 'CALL',

        // --- Data Definition Language (DDL) ---
        'CREATE', 'ALTER', 'DROP', 'TRUNCATE', 'RENAME', 'COMMENT',

        // --- Transaction Control Language (TCL) ---
        'COMMIT', 'ROLLBACK', 'SAVEPOINT', 'SET TRANSACTION',

        // --- Data Control Language (DCL) ---
        'GRANT', 'REVOKE',

        // --- Common Clauses & Operators ---
        'FROM', 'WHERE', 'JOIN', 'INNER', 'OUTER', 'LEFT', 'RIGHT', 'FULL',
        'GROUP BY', 'ORDER BY', 'HAVING', 'LIMIT', 'OFFSET', 'USING', 'AS',

        // --- Set Operators ---
        'UNION', 'INTERSECT', 'EXCEPT', 'MINUS',

        // --- Logical & Comparison Operators ---
        'AND', 'OR', 'NOT', 'IN', 'BETWEEN', 'LIKE', 'IS NULL', 'EXISTS', 
        'ANY', 'ALL', 'SOME',

        // --- Functions & High-Risk Keywords ---
        'SLEEP', 'BENCHMARK', 'WAITFOR', 'DELAY', 'EXEC', 'EXECUTE', 'DECLARE',
        'LOAD_FILE', 'OUTFILE', 'DUMPFILE', 'CHAR', 'CONVERT', 'CAST',
        'DATABASE', 'SCHEMA', 'USER', 'SYSTEM_USER', 'SESSION_USER',

        // --- Information Schema & System Tables ---
        'INFORMATION_SCHEMA', 'PG_CATALOG', 'TABLE_SCHEMA', 'TABLE_NAME', 
        'COLUMN_NAME', 'SCHEMATA', 'TABLES', 'COLUMNS',

        // --- Miscellaneous ---
        'TRUE', 'FALSE', 'NULL', 'DEFAULT', 'DISTINCT', 'PROCEDURE', 'FUNCTION',
        'TRIGGER', 'VIEW', 'INDEX', 'CASE', 'WHEN', 'THEN', 'ELSE', 'END', 'BY'
    ];
    
    $previous_input = '';

    // Loop until the string no longer changes after filtering
    while ($previous_input !== $input) {
        $previous_input = $input;
        // Replace all keywords in one go
        $input = str_ireplace($keywords, '', $input);
    }
    
    // Remove all digits after recursive filtering is complete
    $input = preg_replace('/\d/', '', $input);
    
    return $input;
}

// Process login attempt
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = $_POST['user'] ?? '';
    $pass = $_POST['pass'] ?? '';
    
    // Apply filtering in sequence: character scrub -> keyword scrub
    $filtered_user = strip_characters($user);
    $filtered_pass = strip_characters($pass);
    
    // Store pre-keyword-scrub version for session
    $session_user = $filtered_user;
    
    $filtered_user = filter_tokens($filtered_user);
    $filtered_pass = filter_tokens($filtered_pass);
    
    // SQL query construction 
    $conn = get_db_connection();
    $query = "SELECT * FROM managers WHERE handle = '$filtered_user' AND secret = '$filtered_pass'";
    header("DEBUG-SQL-Query: $query");
    $result = $conn->query($query);

    // Rate Limit
    sleep(1);

    if ($result && $result->num_rows > 0) {
        // Successful authentication
        $_SESSION['who'] = $session_user;
        $_SESSION['ok'] = 'yes';
        redirect('hub.php');
    } else {
        // Failed authentication
        redirect('gate.php?msg=fail');
    }
    
    $conn->close();
} else {
    // Invalid request method
    redirect('gate.php');
}
?>


