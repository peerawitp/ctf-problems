# Advanced Factor War (Hard)

## Story
คุณได้คีย์สาธารณะประหลาดที่ดูเหมือน RSA แต่โมดูลัสถูกสร้างจาก **หลาย prime (multi‑prime)** 
แถมยังมีร่องรอยว่ามีการลงลายเซ็นด้วย **CRT** ที่เคยผิดพลาด และมี public key แปลก ๆ อีกสองตัว
เป้าหมายสุดท้ายคือถอดรหัส ciphertext เพื่อกู้ **FLAG**

## Files
- **Stage 1 (Obfuscation):** `stage1_frag_*.txt` — ชุดไฟล์สับเปลี่ยนที่เข้ารหัสค่าของ N ด้วยสัญลักษณ์ (ฐาน 8)
- **Stage 2 (Hastad / Broadcast, e=3):** `stage2_pubA.pem/B.pem/C.pem` + `stage2_cA.bin/cB.bin/cC.bin` — จงกู้ข้อความบอกใบ้ (mapping + ลำดับชิ้นส่วน + ค่า e)
- **Stage 3 (GCD share):** `stage3_pub_aux1.pem`, `stage3_pub_aux2.pem` + `stage3_c_aux1.bin/c_aux2.bin` — โมดูลัสสองชุดที่ **แชร์ prime คนละตัว** กับโมดูลัสหลัก
- **Stage 4 (CRT fault):** `stage4_message.bin`, `stage4_sign_ok.bin`, `stage4_sign_faulty.bin` — ลายเซ็นถูก/ผิดของข้อความเดียวกัน ภายใต้โมดูลัสหลัก
- **Final:** `public_main.pem`, `final_cipher.bin` — เมื่อได้ N และรู้ e แล้ว จงถอดรหัสให้ได้ FLAG

## What to do
1. **Stage 2 ก่อน**: ใช้ CRT รวม ciphertext ทั้งสาม (e=3, ไม่มี padding) เพื่อถอดข้อความบอกใบ้: 
   - mapping สัญลักษณ์ ↔ ดิจิตฐาน 8
   - ลำดับที่ถูกต้องของไฟล์ `stage1_frag_*.txt`
   - ค่า `E=65537`
2. **Stage 1**: ใช้ mapping + ลำดับชิ้นส่วนที่ได้ เพื่อรวมและถอดรหัสเป็นเลขฐาน 8 → แปลงเป็นจำนวนเต็ม = **N**
3. **Stage 3**: คำนวณ \( \gcd(N, N_{aux1}) \) และ \( \gcd(N, N_{aux2}) \) จะได้ prime สองตัวของ N
4. **Stage 4**: ใช้สมบัติ fault‑attack: \( \gcd(N, s_{ok} - s_{faulty}) \) จะให้ prime อีกตัวหนึ่งของ N
5. เมื่อได้ prime เพียงพอแล้ว จง factor N ให้ครบทั้งหมด → หา \(\varphi(N)\) → คำนวณ \(d = e^{-1} \bmod \varphi(N)\) → ถอดรหัส `final_cipher.bin`

## Output
พิมพ์ FLAG ในฟอร์แมต:
```
flag{...}
```
